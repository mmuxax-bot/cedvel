import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Məxfilik Siyasəti', style: GoogleFonts.poppins()),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Cədvəl – Məxfilik Siyasəti',
              style: GoogleFonts.poppins(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Son yenilənmə: 13 Sentyabr 2026',
              style: GoogleFonts.poppins(color: Colors.grey, fontSize: 13),
            ),
            const SizedBox(height: 24),

            _section(
              '1. Giriş',
              'Cədvəl sizin məxfiliyinizə hörmət edir. Bu siyasət tətbiqdən istifadə zamanı məlumatların necə idarə olunduğunu izah edir.\n\nCədvəl tamamilə lokal işləyən tətbiqdir. Heç bir şəxsi məlumat serverə göndərilmir.',
            ),
            _section(
              '2. Hansı məlumatları toplayırıq?',
              'Biz toplamırıq:\n• Ad, e-poçt, telefon\n• Yer məlumatı\n• Kontaktlar\n• Analitika və izləmə məlumatları\n\nYalnız sizin daxil etdiyiniz planlar cihazınızda (SharedPreferences) saxlanılır.',
            ),
            _section(
              '3. Məlumatların istifadəsi',
              'Lokal məlumatlar yalnız planları göstərmək və statistika hesablamaq üçün istifadə olunur.',
            ),
            _section(
              '4. Üçüncü tərəflər',
              'Tətbiq heç bir üçüncü tərəf xidməti (reklam, analitika və s.) istifadə etmir. Məlumat paylaşılmır.',
            ),
            _section(
              '5. Məlumatların silinməsi',
              'İstədiyiniz zaman planları silə və ya tətbiqi cihazınızdan silməklə bütün məlumatları silə bilərsiniz.',
            ),
            _section(
              '6. Əlaqə',
              'Suallarınız üçün:\nNibras Code\nE-poçt: support@nibrascode.com',
            ),

            const SizedBox(height: 30),
            Center(
              child: Text(
                'Nibras Code © 2026',
                style: GoogleFonts.poppins(color: Colors.grey, fontSize: 12),
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _section(String title, String body) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.poppins(
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            body,
            style: GoogleFonts.poppins(
              fontSize: 14,
              height: 1.5,
              color: Colors.grey[800],
            ),
          ),
        ],
      ),
    );
  }
}
