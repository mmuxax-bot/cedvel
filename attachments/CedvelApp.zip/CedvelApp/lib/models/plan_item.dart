import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

enum PlanType { lesson, task, event, note }

class PlanItem {
  final String id;
  String title;
  String? subtitle;
  String? location;
  DateTime startTime;
  DateTime endTime;
  PlanType type;
  Color color;
  bool isCompleted;
  String? note;

  PlanItem({
    String? id,
    required this.title,
    this.subtitle,
    this.location,
    required this.startTime,
    required this.endTime,
    this.type = PlanType.lesson,
    this.color = const Color(0xFF6C5CE7),
    this.isCompleted = false,
    this.note,
  }) : id = id ?? const Uuid().v4();

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'subtitle': subtitle,
        'location': location,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'type': type.index,
        'color': color.value, // ignore: deprecated_member_use


        'isCompleted': isCompleted,
        'note': note,
      };

  factory PlanItem.fromJson(Map<String, dynamic> json) => PlanItem(
        id: json['id'],
        title: json['title'],
        subtitle: json['subtitle'],
        location: json['location'],
        startTime: DateTime.parse(json['startTime']),
        endTime: DateTime.parse(json['endTime']),
        type: PlanType.values[json['type'] ?? 0],
        color: Color(json['color'] ?? 0xFF6C5CE7),
        isCompleted: json['isCompleted'] ?? false,
        note: json['note'],
      );

  PlanItem copyWith({
    String? title,
    String? subtitle,
    String? location,
    DateTime? startTime,
    DateTime? endTime,
    PlanType? type,
    Color? color,
    bool? isCompleted,
    String? note,
  }) {
    return PlanItem(
      id: id,
      title: title ?? this.title,
      subtitle: subtitle ?? this.subtitle,
      location: location ?? this.location,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      type: type ?? this.type,
      color: color ?? this.color,
      isCompleted: isCompleted ?? this.isCompleted,
      note: note ?? this.note,
    );
  }
}
