import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/plan_item.dart';

class PlanService extends ChangeNotifier {
  static const int freePlanLimit = 7;

  List<PlanItem> _plans = [];
  bool _isPremium = false;
  String _userName = 'Həkim';
  ThemeMode _themeMode = ThemeMode.system;
  List<String> _categories = ['Dərs', 'Tapşırıq', 'Tədbir', 'Şəxsi'];
  bool _onboardingDone = false;
  bool _loaded = false;

  List<PlanItem> get plans => List.unmodifiable(_plans);
  bool get isPremium => _isPremium;
  String get userName => _userName;
  ThemeMode get themeMode => _themeMode;
  List<String> get categories => List.unmodifiable(_categories);
  bool get onboardingDone => _onboardingDone;
  bool get isLoaded => _loaded;

  /// Free users: max 7 plans. Premium: unlimited.
  bool get canAddPlan => _isPremium || _plans.length < freePlanLimit;

  int get remainingFreeSlots {
    if (_isPremium) return 999;
    return (freePlanLimit - _plans.length).clamp(0, freePlanLimit);
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('plans');
    _isPremium = prefs.getBool('isPremium') ?? false;
    _userName = prefs.getString('userName') ?? 'Həkim';
    _onboardingDone = prefs.getBool('onboardingDone') ?? false;
    final themeIndex = prefs.getInt('themeMode') ?? 0;
    _themeMode = ThemeMode.values[themeIndex.clamp(0, 2)];
    final cats = prefs.getStringList('categories');
    if (cats != null && cats.isNotEmpty) _categories = cats;

    if (data != null) {
      final list = jsonDecode(data) as List;
      _plans = list.map((e) => PlanItem.fromJson(e)).toList();
    } else {
      _plans = _createDemoData();
      await save();
    }
    _loaded = true;
    notifyListeners();
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('plans', jsonEncode(_plans.map((e) => e.toJson()).toList()));
    await prefs.setBool('isPremium', _isPremium);
    await prefs.setString('userName', _userName);
    await prefs.setInt('themeMode', _themeMode.index);
    await prefs.setStringList('categories', _categories);
    await prefs.setBool('onboardingDone', _onboardingDone);
  }

  void completeOnboarding() {
    _onboardingDone = true;
    save();
    notifyListeners();
  }

  void setUserName(String name) {
    _userName = name.trim().isEmpty ? 'İstifadəçi' : name.trim();
    save();
    notifyListeners();
  }

  void setThemeMode(ThemeMode mode) {
    _themeMode = mode;
    save();
    notifyListeners();
  }

  void addCategory(String name) {
    if (name.trim().isEmpty || _categories.contains(name.trim())) return;
    // Free: max 4 categories
    if (!_isPremium && _categories.length >= 4) return;
    _categories.add(name.trim());
    save();
    notifyListeners();
  }

  void removeCategory(String name) {
    _categories.remove(name);
    save();
    notifyListeners();
  }

  /// Returns false if limit reached (caller should show premium).
  bool addPlan(PlanItem item) {
    if (!canAddPlan) return false;
    _plans.add(item);
    save();
    notifyListeners();
    return true;
  }

  void updatePlan(PlanItem item) {
    final index = _plans.indexWhere((e) => e.id == item.id);
    if (index != -1) {
      _plans[index] = item;
      save();
      notifyListeners();
    }
  }

  void deletePlan(String id) {
    _plans.removeWhere((e) => e.id == id);
    save();
    notifyListeners();
  }

  void toggleComplete(String id) {
    final index = _plans.indexWhere((e) => e.id == id);
    if (index != -1) {
      _plans[index].isCompleted = !_plans[index].isCompleted;
      save();
      notifyListeners();
    }
  }

  void setPremium(bool value) {
    _isPremium = value;
    save();
    notifyListeners();
  }

  void clearAllPlans() {
    _plans.clear();
    save();
    notifyListeners();
  }

  List<PlanItem> getPlansForDay(DateTime day) {
    return _plans.where((p) {
      return p.startTime.year == day.year &&
          p.startTime.month == day.month &&
          p.startTime.day == day.day;
    }).toList()
      ..sort((a, b) => a.startTime.compareTo(b.startTime));
  }

  List<PlanItem> getPlansForWeek(DateTime weekStart) {
    final end = weekStart.add(const Duration(days: 7));
    return _plans.where((p) {
      return p.startTime.isAfter(weekStart.subtract(const Duration(seconds: 1))) &&
          p.startTime.isBefore(end);
    }).toList()
      ..sort((a, b) => a.startTime.compareTo(b.startTime));
  }

  List<PlanItem> search(String query) {
    if (query.trim().isEmpty) return plans;
    final q = query.toLowerCase();
    return _plans.where((p) {
      return p.title.toLowerCase().contains(q) ||
          (p.subtitle?.toLowerCase().contains(q) ?? false) ||
          (p.location?.toLowerCase().contains(q) ?? false) ||
          (p.note?.toLowerCase().contains(q) ?? false);
    }).toList();
  }

  String exportToJson() {
    return const JsonEncoder.withIndent('  ').convert(_plans.map((e) => e.toJson()).toList());
  }

  String exportToCsv() {
    final buffer = StringBuffer();
    buffer.writeln('Başlıq,Alt başlıq,Məkan,Başlama,Bitmə,Növ,Tamamlanıb,Qeyd');
    for (final p in _plans) {
      buffer.writeln([
        '"${p.title}"',
        '"${p.subtitle ?? ''}"',
        '"${p.location ?? ''}"',
        p.startTime.toIso8601String(),
        p.endTime.toIso8601String(),
        p.type.name,
        p.isCompleted,
        '"${p.note ?? ''}"',
      ].join(','));
    }
    return buffer.toString();
  }

  double getCompletionRate() {
    if (_plans.isEmpty) return 0;
    return _plans.where((p) => p.isCompleted).length / _plans.length;
  }

  List<PlanItem> _createDemoData() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    return [
      PlanItem(
        title: 'Hesab dərsi',
        subtitle: 'Riyaziyyat',
        location: 'Sinif 301',
        startTime: today.add(const Duration(hours: 9)),
        endTime: today.add(const Duration(hours: 10, minutes: 30)),
        type: PlanType.lesson,
        color: const Color(0xFF6C5CE7),
      ),
      PlanItem(
        title: 'Fizika',
        subtitle: 'Laboratoriya',
        location: 'Lab 2',
        startTime: today.add(const Duration(hours: 11)),
        endTime: today.add(const Duration(hours: 12, minutes: 30)),
        type: PlanType.lesson,
        color: const Color(0xFF00CEC9),
      ),
      PlanItem(
        title: 'İngilis dili',
        subtitle: 'Speaking practice',
        startTime: today.add(const Duration(hours: 14)),
        endTime: today.add(const Duration(hours: 15, minutes: 30)),
        type: PlanType.lesson,
        color: const Color(0xFFE17055),
      ),
      PlanItem(
        title: 'Tapşırıq: Referat',
        subtitle: 'Tarix fənni',
        startTime: today.add(const Duration(hours: 16)),
        endTime: today.add(const Duration(hours: 17)),
        type: PlanType.task,
        color: const Color(0xFFFDCB6E),
      ),
      PlanItem(
        title: 'İdman',
        subtitle: 'Futbol',
        location: 'Stadion',
        startTime: today.add(const Duration(hours: 18)),
        endTime: today.add(const Duration(hours: 19, minutes: 30)),
        type: PlanType.event,
        color: const Color(0xFF00B894),
      ),
    ];
  }
}
