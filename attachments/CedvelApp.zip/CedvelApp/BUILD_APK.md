# Cədvəl — APK Build (1 dəfəlik təlimat)

## Tələblər
- Flutter 3.16+ (`flutter doctor` yaşıl olsun)
- Android Studio və ya Android SDK

## Addımlar

```bash
# 1. ZIP aç
unzip CedvelApp.zip
cd CedvelApp

# 2. Platform fayllarını tamamla (mütləq)
flutter create . --project-name cedvel --org com.nibrascode

# 3. Paketlər
flutter pub get

# 4. Test
flutter run

# 5. APK (debug imza — test üçün kifayətdir)
flutter build apk --release

# Nəticə:
# build/app/outputs/flutter-apk/app-release.apk
```

## Play Store üçün (AAB + real imza)

```bash
# Keystore (bir dəfə)
keytool -genkey -v -keystore nibras-cedvel.jks -keyalg RSA -keysize 2048 -validity 10000 -alias cedvel

# key.properties
cp android/key.properties.example android/key.properties
# İçini öz şifrələrinlə doldur

# AAB
flutter build appbundle --release
# build/app/outputs/bundle/release/app-release.aab
```

## Qeyd
- `flutter create .` mövcud `lib/` və `pubspec.yaml`-ı silmir
- Keystore və `key.properties`-i GitHub-a yükləmə
- Privacy Policy public URL Play Console üçün mütləqdir
